package kh.java.vo;

public class NovleEssay extends Books{
	
	private String genre;
	public NovleEssay() {
		
	}
	public NovleEssay(String name, String writer, int price, int stock, String genre) {
		super(name, writer, price, stock);
		this.genre = genre;
	}
	
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	

}
