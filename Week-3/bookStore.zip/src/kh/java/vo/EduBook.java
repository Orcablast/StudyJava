package kh.java.vo;

public class EduBook extends Books {
	
	public EduBook() {}
	
	public EduBook(String name,String writer,String genre, int price, int stock) {
		super(name, writer,genre, price, stock);
	}
}
