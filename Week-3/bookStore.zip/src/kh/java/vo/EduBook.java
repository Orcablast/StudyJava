package kh.java.vo;

public class EduBook extends Books {
	
	public EduBook() {}
	
	public EduBook(String name, String writer, int price, int stock) {
		super(name, writer, price, stock);
	}
}
