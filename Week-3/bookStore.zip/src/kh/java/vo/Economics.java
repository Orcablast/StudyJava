
public class Economics extends Books{
	public Economics() {		
	}
	
	public Economics(String name,String writer,int price, int stock) {
		super(name,writer,price,stock)
		
	}
	

}
