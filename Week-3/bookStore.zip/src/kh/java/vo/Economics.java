package kh.java.vo;

public class Economics extends Books{
	public Economics() {		
	}
	
	public Economics(String name,String writer,String genre, int price, int stock) {
		super(name,writer,genre,price,stock);
		
	}
	

}
