package kh.java.run;

import kh.java.controller.Controll;

public class Start {

	public static void main(String[] args) {
		Controll cn = new Controll();
		cn.main();
	}

}
