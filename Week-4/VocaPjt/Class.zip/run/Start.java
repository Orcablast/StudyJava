package run;

import VO.Word;
import controller.updateWord;

public class Start {
	public static void main(String[] args) {
		new updateWord().updateMain();
		
	}

}
